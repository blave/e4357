//
//  TableViewController.m
//  SimpleControl
//
//  Created by Cheong on 7/11/12.
//  Copyright (c) 2012 RedBearLab. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()

@end

@implementation TableViewController

@synthesize ble;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    ble = [[BLE alloc] init];
    [ble controlSetup];
    ble.delegate = self;
    
    
    sw_LED1.on=false;
    sw_LED2.on=false;
    sw_LED3.on=false;
    sw_LED4.on=false;
    sw_RedLed.on=false;
    sw_YellowLed.on=false;
    
    
    sw_LED1.enabled=false;
    sw_LED2.enabled=false;
    sw_LED3.enabled=false;
    sw_LED4.enabled=false;
    sw_RedLed.enabled=false;
    sw_YellowLed.enabled=false;
    
    self.DateRecord=[NSDate date];
    CGAffineTransform transform = CGAffineTransformMakeScale(1.0f, 12.0f);
    sensor1.transform= transform;
    sensor2.transform= transform;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - BLE delegate

NSTimer *rssiTimer;
NSTimer *dataTimer;

- (void)bleDidDisconnect
{
    NSLog(@"->Disconnected");
    
    [btnConnect setTitle:@"Connect" forState:UIControlStateNormal];
    [indConnecting stopAnimating];
    
    //  disable switch when disconnected.
    sw_LED1.enabled=false;
    sw_LED2.enabled=false;
    sw_LED3.enabled=false;
    sw_LED4.enabled=false;
    sw_RedLed.enabled=false;
    sw_YellowLed.enabled=false;
    slider_YellowLed.enabled=false;
    
    sw_LED1.on=false;
    sw_LED2.on=false;
    sw_LED3.on=false;
    sw_LED4.on=false;
    sw_RedLed.on=false;
    sw_YellowLed.on=false;
    slider_YellowLed.value=0;
    
    lblRSSI.text = @"---";
    [rssiTimer invalidate];
}

// When RSSI is changed, this will be called
-(void) bleDidUpdateRSSI:(NSNumber *) rssi
{
    lblRSSI.text = rssi.stringValue;
     NSLog (@"bbb");
}

-(void) readRSSITimer:(NSTimer *)timer
{
    [ble readRSSI];
}

//-(void) readData:(NSTimer *)timer
//{
  //  [ble read];
  //  NSLog (@"aaa");
//}

// When disconnected, this will be called
-(void) bleDidConnect
{
    NSLog(@"->Connected");
    
    [indConnecting stopAnimating];
    
    //enable switch
    sw_LED1.enabled=true;
    sw_LED2.enabled=true;
    sw_LED3.enabled=true;
    sw_LED4.enabled=true;
    sw_RedLed.enabled=true;
    sw_YellowLed.enabled=true;
    slider_YellowLed.enabled=true;
    
    // send reset
    UInt8 buf[] = {0x04, 0x00, 0x00};
    NSData *data = [[NSData alloc] initWithBytes:buf length:3];
    [ble write:data];
    
    // Schedule to read RSSI every 1 sec.
    rssiTimer = [NSTimer scheduledTimerWithTimeInterval:(float)1.0 target:self selector:@selector(readRSSITimer:) userInfo:nil repeats:YES];
   // dataTimer = [NSTimer scheduledTimerWithTimeInterval:(float)1.0 target:self selector:@selector(readData:) userInfo:nil repeats:YES];
}

// When data is comming, this will be called
-(void) bleDidReceiveData:(unsigned char *)data length:(int)length
{
    NSLog(@"Length: %d", length);
    
    // parse data, all commands are in 3-byte
        for (int i = 0; i < length; i+=3)
     {
         NSLog(@"%c, %c, %c", data[i], data[i+1], data[i+2]);}
    //sensor1.progress=0.5;
    for (int i=0; i<length; i+=1)
    {
     if (data[i] == 'F')
     {
         float value=0;
         int j=1;
         while (data[j+i]!='f')
         { value= value*10 + (int)(data[j]-'0');
             j=j+1;
             }
         i=i+j;
         NSLog(@"Benty value= %f", value);
         sensor1.progress=(value-140)/60;
         
     }
    
    if (data[i] == 'T')
    {
        float value2=0;
        int k=1;
        while (data[k+i]!='t')
        { value2= value2*10 + (int)(data[k+i]-'0');
            k=k+1;
        }
        i=i+k;
        NSLog(@"Temp value= %f", value2);
        sensor2.progress=(value2-15)/15;
    }
    }
}

#pragma mark - Actions

// Connect button will call to this
- (IBAction)btnScanForPeripherals:(id)sender
{
    if (ble.activePeripheral)
        if(ble.activePeripheral.state == CBPeripheralStateConnected)
        {
            [[ble CM] cancelPeripheralConnection:[ble activePeripheral]];
            [btnConnect setTitle:@"Connect" forState:UIControlStateNormal];
            return;
        }
    
    if (ble.peripherals)
        ble.peripherals = nil;
    
    [btnConnect setEnabled:false];
    [ble findBLEPeripherals:2];
    
    [NSTimer scheduledTimerWithTimeInterval:(float)2.0 target:self selector:@selector(connectionTimer:) userInfo:nil repeats:NO];
    
    [indConnecting startAnimating];
}

-(void) connectionTimer:(NSTimer *)timer
{
    [btnConnect setEnabled:true];
    [btnConnect setTitle:@"Disconnect" forState:UIControlStateNormal];
    
    if (ble.peripherals.count > 0)
    {
        [ble connectPeripheral:[ble.peripherals objectAtIndex:0]];
    }
    else
    {
        [btnConnect setTitle:@"Connect" forState:UIControlStateNormal];
        [indConnecting stopAnimating];
    }
}

//send data to toggle LED1
- (IBAction)sendLED1:(id)sender {
    
    UInt8 buf[]={0x00};
    
    if (sw_LED1.on) {
        buf[0]=0x01;
    }
    else
        buf[0]=0x02;
    NSData *data = [[NSData alloc] initWithBytes:buf length:1];
    [ble write:data];
    
}

- (IBAction)sendLED2:(id)sender {
    UInt8 buf[]={0x00};
    
    if (sw_LED2.on) {
        buf[0]=0x03;
    }
    else
        buf[0]=0x04;
    NSData *data = [[NSData alloc] initWithBytes:buf length:1];
    [ble write:data];
}

- (IBAction)sendLED3:(id)sender {
    UInt8 buf[]={0x00};
    
    if (sw_LED3.on) {
        buf[0]=0x05;
    }
    else
        buf[0]=0x06;
    NSData *data = [[NSData alloc] initWithBytes:buf length:1];
    [ble write:data];
}


- (IBAction)sendLED4:(id)sender {
    UInt8 buf[]={0x00};
    if (sw_LED4.on) {
        buf[0]=0x07;
    }
    else
        buf[0]=0x08;
    NSData *data = [[NSData alloc] initWithBytes:buf length:1];
    [ble write:data];
}



- (IBAction)RedLedswitch:(UISwitch *)sender {
    UInt8 buf[]={0x00};
    if (sw_RedLed.on) {
        buf[0]=0x10;
    }
    else
        buf[0]=0x11;
    NSData *data = [[NSData alloc] initWithBytes:buf length:1];
    [ble write:data];
}


- (IBAction)YellowLedtune:(UISlider *)sender {
    UInt8 buf[]={0x14, 0X00};
    int YellowLedvalue=(int)sender.value;
    buf[1]=YellowLedvalue;
   // NSLog(@"Length: %d", buf[1]);
    NSData *data= [[NSData alloc] initWithBytes:buf length:2];
    //[ble write:data];
    NSDate *Date=[NSDate date];
    NSTimeInterval distanceBetweenDates = [Date timeIntervalSinceDate:self.DateRecord];
   // NSLog(@"Time1: %f",distanceBetweenDates);
    if (distanceBetweenDates > 0.2)
    {
        [ble write:data];
        NSLog(@"Length: %d", buf[1]);
        NSLog(@"Time: %f",distanceBetweenDates);
        self.DateRecord=[NSDate date];
    }
}
@end
