//
//  TableViewController.h
//  SimpleControl
//
//  Created by Cheong on 7/11/12.
//  Copyright (c) 2012 RedBearLab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLE.h"

@interface TableViewController : UITableViewController <BLEDelegate>
{
    IBOutlet UIButton *btnConnect;
    IBOutlet UIActivityIndicatorView *indConnecting;
    IBOutlet UILabel *lblRSSI;
    
    
    __weak IBOutlet UILabel *label_LED1;
    __weak IBOutlet UILabel *label_LED2;
    __weak IBOutlet UILabel *label_LED3;
    __weak IBOutlet UILabel *label_LED4;
    
    
    __weak IBOutlet UISwitch *sw_LED1;
    __weak IBOutlet UISwitch *sw_LED2;
    __weak IBOutlet UISwitch *sw_LED3;
    __weak IBOutlet UISwitch *sw_LED4;
    
    __weak IBOutlet UISwitch *sw_RedLed;
    __weak IBOutlet UISwitch *sw_YellowLed;
    
    __weak IBOutlet UISlider *slider_YellowLed;
    __weak IBOutlet UIProgressView *sensor1;
    __weak IBOutlet UIProgressView *sensor2;
}
- (IBAction)RedLedswitch:(UISwitch *)sender;
- (IBAction)YellowLedtune:(UISlider *)sender;

@property (strong, nonatomic) BLE *ble;
@property (strong, nonatomic) NSDate *DateRecord;

@end
